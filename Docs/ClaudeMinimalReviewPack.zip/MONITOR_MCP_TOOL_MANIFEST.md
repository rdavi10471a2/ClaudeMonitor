﻿# Monitor MCP Tool Manifest

This server is the MCP workflow API for the monitor source implementation at:

```text
C:\VSCodeProjects\ClaudeMonitor\Monitor
```

The WinForms operator UI lives at:

```text
C:\VSCodeProjects\MonitorBaseClaude
```

The new MCP server lives beside it:

```text
C:\VSCodeProjects\MonitorBaseClaude\MonitorBaseClaude.McpServer
```

The current watched solution is:

```text
C:\Schema Studio - DBV2\Schema Studio.sln
```

## Tool Surface Rule

The command-line monitor behavior is represented here as typed MCP tools and typed tool arguments.

The WinForms UI should call this MCP server for workflow state, file operations, sessions, staged changes, and review actions.

Claude/Codex-style clients should treat this server as the workflow and safety surface, not as a raw filesystem editor. The small core should be easy for a Model to discover:

- status and tool manifest
- find/read/source-map/outline/symbol reads
- staged whole-file replacement
- explicit review outcome classification

The expected edit loop is:

```text
find related files
read source maps for the target file/folder
read only the needed symbols or full files
stage a complete candidate
Host/sidecar opens the sanity diff
Operator either saves the full candidate in WinMerge or leaves source unchanged
record_diff_decision classifies by vote-plus-hash agreement
```

Models are allowed and expected to read related files under the watched root when the change requires context. The preferred first read for C# is `get_source_map`, because it gives the real current structure without forcing a whole-file read.

Source maps and context anchors must not depend on decorative glyphs, emoji, or process comments. If source already contains such text, treat it as legacy content, not as an edit marker. Routine workflow notes belong in Monitor-owned records, not watched source.

Larger editing capabilities should remain documented in this manifest until implemented, then can be exposed as normal MCP tools or through client-side deferred tool loading where available.

## Canonical Agent Tool Sequences

These sequences are part of the tool contract. They are intentionally small so an MCP client can learn the loop before using broader edit tools.

### C# Preservation Edit

```text
find_file, unless the full path was returned by a Roslyn or Monitor tool in this session
get_source_map(path, scope: "file", mode: "selector")
get_symbol(path, symbolSelectorJson)
submit_file or submit_symbol
launch_staged_diff or Host/sidecar WinMerge review/save
record_diff_decision(stagedRecordId, accepted|rejected)
```

Expected behavior:

- Use `get_source_map` before full `get_file` for C# edits.
- Use `get_symbol` for the smallest needed body.
- Use a structured selector or `stableSymbolKey` when available.
- For symbol staging or removal, prefer `stableSymbolKey` or structured `symbolSelectorJson`; name-only `symbolName` is a fallback of last resort for read compatibility, not mutation authority.
- Stage a complete candidate; do not directly mutate watched source.
- Use `launch_staged_diff` when the MCP client has no separate Host or sidecar available to open WinMerge.
- Treat `record_diff_decision` as vote-plus-hash agreement.
- Do not perform DRY cleanup or helper extraction as a side effect of a narrow change.

### Related-File Context

```text
find_file for likely interfaces/models/options/tests
get_source_map on related C# files or folders
get_symbol for only the bodies needed to understand the change
get_file only when the source-map/symbol lane is insufficient
```

Related files may be read when they materially affect correctness. The goal is not to forbid context; the goal is to make context narrow, current, and anchored to real source structure.

### Unsafe Requests

```text
Direct watched-source write -> refuse and use staging.
Manual WinMerge repair or partial hunk merge -> refuse and regenerate a smaller candidate.
Name-only mutation -> read source map and build a structured selector.
dirty-unexpected -> stop editing that file until Host/Operator refreshes or inspects state.
blocked-dirty-unexpected record -> do not re-vote to accepted/rejected; recover explicitly.
```

### No-Op Candidate

```text
stagedCandidateHash == originalBaselineHash
-> return no-change/no-op-staged
-> do not enqueue a normal diff by default
```

This prevents Accept and Reject from collapsing into the same raw hash state.

## Tool Map

| Source behavior | MCP tool target | Status |
| --- | --- | --- |
| `--help` | `get_tool_manifest` | scaffolded |
| Claude staging guide | `get_staging_guide` | scaffolded |
| smoke-test catalog | `get_smoke_test_catalog` | debug-only |
| `--self-check` | `get_self_check` | scaffolded |
| `WorkflowSettings:ObservedRoot` | `get_monitor_status.watchedSolutionPath` | scaffolded |
| source file path argument | `refresh_file.sourceFilePath` | scaffolded |
| `--refresh-only` | `refresh_file` | scaffolded |
| default refresh then compare | `refresh_and_compare_file` | planned |
| `--compare-only` | `compare_file` | scaffolded |
| `--ledger-summary` | `ledgerSummary` argument on compare tools | scaffolded |
| `--observed-root` | `watchedSolutionPath` / project context argument | planned |
| `--telemetry-window` | WinForms telemetry surface | planned |
| `_runs.json` | `list_monitor_runs`, `get_monitor_run` | scaffolded |
| `_telemetry.json` | `list_telemetry_runs`, `get_telemetry_run` | planned |
| Ledgers under `Working\History\Ledgers` | `list_ledgers`, `get_ledger` | scaffolded |
| model/context token usage | Host telemetry / future `record_model_usage` | planned |
| source file read | `get_file` | scaffolded |
| source file discovery | `find_file` | scaffolded |
| explicit durable state handle | `start_monitor_session`, `get_monitor_session`, `record_monitor_session_event`, `list_monitor_sessions` | scaffolded |
| session file hash tracking | `check_file_hash`, `get_file.sessionId` | scaffolded |
| token-saving outline reads | `get_file_outline`, `get_symbol` | scaffolded |
| staged whole-file replacement | `submit_file` | scaffolded |
| staged symbol replacement | `submit_symbol` | scaffolded |
| Roslyn type declaration modifier staging | `set_type_partial` | scaffolded |
| Roslyn typed member insertion | `add_field`, `add_property`, `add_method`, `add_constructor`, `add_nested_type` | scaffolded |
| Roslyn generic symbol insertion | `add_symbol`, `add_using` | scaffolded |
| Roslyn symbol removal | `remove_symbol`, `remove_using` | scaffolded |
| Roslyn class insertion/removal | `add_class`, `remove_class` | planned |
| staged candidate WinMerge launch | `launch_staged_diff` | scaffolded |
| diff outcome classification | `record_diff_decision` | scaffolded |
| Roslyn source map | `get_source_map` | implemented |
| old executable command flags | future command-line bridge | breadcrumb only |

## Current Tools

### `get_monitor_status`

Returns path/config status for:

- WinForms UI root
- new MCP server root
- source implementation root
- watched solution
- watched project folder

### `list_watched_projects`

Temporary discovery helper.

### `get_workflow_status`

Returns the watched solution, watched project folder, monitor Working folder, and WinMerge resolution.

### `get_self_check`

Returns configured roots, monitor-owned Working and History paths, watched solution existence, diff tool resolution, and guardrail decisions.

### Session State Tools

MCP clients should not assume implicit per-connection state. The monitor server exposes explicit durable session handles that can outlive one client connection.

- `start_monitor_session(purpose?)`: creates a server-side session handle under `Working\Sessions`.
- `list_monitor_sessions()`: lists known session handles.
- `get_monitor_session(sessionId)`: reads one durable session.
- `record_monitor_session_event(sessionId, eventType, summary, payloadJson?)`: appends an event.
- `check_file_hash(sessionId, sourceFilePath)`: checks whether a watched file has changed since it was last fetched in the session.

For local Ollama, WinForms will use these tools to simulate the host session loop:

1. Start or resume a session.
2. Record user message.
3. Ask Ollama for a strict action JSON.
4. Execute selected MCP tool.
5. Record tool call and tool result.
6. Ask Ollama for final answer.
7. Record final answer.

Storage note: durable sessions and staged edit records remain inspectable text/JSON files for now. SQLite may be added later as a query/index layer for telemetry, sessions, staged records, and run history after the file-based workflow is stable.

### Token And Context Telemetry

Token monitoring is a Host concern first, not a mutation gate.

Current low-risk rule:

- Record provider-reported usage when the Host has it.
- Estimate tool-result payload size for Monitor tools.
- Prefer `get_source_map`, `get_file_outline`, and `get_symbol` before full `get_file`.
- Do not block edits on token estimates.

Provider notes:

- Local Ollama `/api/chat` responses can include `prompt_eval_count` and `eval_count`; the Host can log these as prompt/response token counts.
- OpenAI API responses expose token usage in response metadata.
- Claude Code exposes context/cost/usage through its own UI commands such as `/context`, `/cost`, and `/usage`; Monitor should not depend on scraping those, but a Host integration may let the Operator record the displayed values.

Planned Monitor fields:

- `estimatedInputCharacters`
- `estimatedOutputCharacters`
- `estimatedInputTokens`
- `estimatedOutputTokens`
- `providerPromptTokens`
- `providerCompletionTokens`
- `providerContextTokens`
- `providerContextLimit`
- `contextBudgetWarning`

This is useful telemetry for choosing narrower tools; it is lower priority than the staged edit and decision gate.

### `refresh_file`

Copies a watched source file into the monitor-owned `Working` folder and records refresh state.

Arguments:

- `sourceFilePath`: absolute path or path relative to the watched solution folder.

### `get_file`

Reads a watched source file through the Monitor MCP server.

Arguments:

- `sourceFilePath`: absolute path or path relative to the watched solution folder.
- `sessionId`: optional durable session handle. When supplied, the server records the fetched file hash in the session.

`get_file` returns the full file. Token-efficient partial reads should use outline/symbol tools rather than arbitrary character clipping.

### `check_file_hash`

Checks a watched source file against the hash last recorded in a durable monitor session.

Arguments:

- `sessionId`: durable session handle returned by `start_monitor_session`.
- `sourceFilePath`: absolute path or path relative to the watched solution folder.

Returns:

- whether the file is known in the session
- whether it changed since the last session fetch
- current hash, length, and timestamp
- previously recorded session hash, length, timestamp, and fetch count

### `find_file`

Finds files under the watched project folder by filename or wildcard pattern.

Arguments:

- `fileNameOrPattern`: filename or wildcard pattern, such as `Program.cs` or `*.razor`.
- `maxResults`: maximum matches returned.

Use this to locate target files and related context files before staging. For example, a repository edit may require finding the interface, DTO, options/config file, and tests before the Model proposes a candidate.

### Source Marker And Glyph Rule

Do not add process markers to watched source files:

- no `AI edit here`
- no temporary monitor anchors
- no `... existing code ...`
- no emoji/glyph anchors

Source comments are allowed when they explain real code behavior. Domain metadata such as `AIFileContext` and `FileVersion` is allowed when it is part of the watched project's convention. All routine workflow state belongs in staged records, sessions, ledgers, history, or docs.

### `compare_file`

Creates a proposed snapshot from the monitor Working copy and returns paths for Host-launched WinMerge review against the watched source file.

Compatibility note: older monitor behavior launched WinMerge directly during compare. That is deprecated for the MCP Tool Server path. Host-like clients should launch GUI review tools using the returned paths.

Arguments:

- `sourceFilePath`: absolute path or path relative to the watched solution folder.
- `ledgerSummary`: optional compact summary appended to the monitor-owned ledger.
- `refreshIfMissing`: refreshes from source if the Working copy does not exist.

### `get_file_outline`

Returns a token-saving outline for a watched C# source file.

Arguments:

- `path`: watched source file path, absolute or relative to the watched solution folder.

### `get_source_map`

Returns a read-only Roslyn-derived source map for a C# file, folder, or the watched project.

Arguments:

- `path`: optional watched source file or folder path, absolute or relative to the watched solution folder. Omit for project scope.
- `scope`: `auto`, `file`, `folder`, or `project`.
- `mode`: `auto`, `navigation`, `selector`, `detail`, or `full`.

Mode defaults:

- `scope=file` -> `mode=selector`
- `scope=folder` -> `mode=navigation`
- `scope=project` -> `mode=navigation`

Mode meanings:

- `navigation`: broad orientation. It returns current file/type/member shape, parse status, diagnostic counts, line spans, and lightweight type context. Use it to choose the next file/member without reading bodies.
- `selector`: target selection. It returns stable lexical symbol keys, normalized symbol text hashes, file hashes, compact contract signatures, parameter types, modifiers, flags, and syntax kinds. Use it to build `get_symbol`, `submit_symbol`, or `remove_symbol` selectors.
- `detail`: contract detail. It keeps selector identity plus usings, diagnostics when present, parameter names, and non-AI attribute argument summaries. Use it when interface/shape detail matters but full audit fidelity is unnecessary.
- `full`: audit/debug fidelity. It keeps absolute source paths, diagnostics summaries, usings, empty arrays, and the full source-map schema. Do not use it as broad model context by default.

The response includes `modePurpose`, `estimatedTokenProxy`, `budgetLimit`, `wasTruncated`, optional `suggestedNarrowing`, and ranked `suggestedNextCalls`. `suggestedNextCalls` makes the narrowing hierarchy explicit: navigation responses suggest file-level selector calls; selector responses suggest `get_symbol` calls by structured selector/stable key. Treat them as ranked affordances, not mandatory commands; choose the next call that matches the user's intent.

`budgetLimit` is enforced by the Tool Server. If a shaped response would exceed budget, the Tool Server returns `wasTruncated: true`, omits source-map file payload details, and includes narrowing guidance so the client can retry with less detail.

Event declarations and event fields are surfaced as `event` symbols. Signatures are compact contract signatures, closer to a Visual Studio tree view than a source excerpt, so comments and generated process metadata do not become accidental source-map anchors. Legacy source metadata attributes whose names are `AI*` or `FileVersion` are omitted from source-map output; they remain untouched in source files and remain visible through `get_file` / `get_symbol` / `full` source text. It is a discovery tool; it does not stage or edit files.

This is a published Tier 1 tool, not a background artifact. Use it before C# edits to:

- see the current source shape without reading every body
- find the stable selector for `get_symbol`, `submit_symbol`, or `remove_symbol`
- inspect nearby/related files by folder or project scope
- detect whether a requested change is local, cross-file, or structural
- keep the Model anchored to the prior converged pattern before generating code

The source map is not an accept/reject verifier. The final gate remains `record_diff_decision` with vote-plus-hash agreement.

### `get_symbol`

Returns one C# symbol body from a watched source file.

Arguments:

- `path`: watched source file path, absolute or relative to the watched solution folder.
- `symbolName`: optional compatibility method/type/member name to locate. It must be unambiguous.
- `symbolSelectorJson`: optional structured selector JSON from `get_source_map`.

Selector behavior:

- Accept selectors from `get_source_map`, especially `stableSymbolKey`, `memberKind`, `containingNamespace`, `containingType`, `parameterTypes`, and `arity`.
- Reject ambiguous matches instead of falling back to name-only behavior.
- Keep `symbolName` only as a compatibility shortcut for unambiguous files.

### `submit_file`

Stages a complete replacement file under monitor-owned `Working\Staged`, writes a timestamped `StagedEditRecord`, derives Roslyn metadata, runs syntax validation, runs overlay compile validation, and returns staged/source paths. C# parse/syntax errors are rejected before a staged record is written. Overlay compile diagnostics are reported on staged candidates because project/reference state can produce false positives.

Arguments:

- `path`: watched source file path, absolute or relative to the watched solution folder.
- `content`: complete replacement file content.
- `sessionId`: optional durable session handle.
- `manifestJson`: optional Model-intent manifest. It is recorded but not trusted for verification.
- `launchDiff`: deprecated compatibility flag. Always pass `false`. GUI diff launch is the Host or sidecar's responsibility. There is no agent-side case where `true` is correct.

### `submit_symbol`

Stages replacement of one C# symbol selected by structured selector JSON. The tool generates a full staged candidate file and never overwrites watched source directly.

Arguments:

- `path`: watched source file path, absolute or relative to the watched solution folder.
- `symbolSelectorJson`: JSON selector with fields such as `containingNamespace`, `containingType`, `memberKind`, `name`, `parameterTypes`, `arity`, and `stableSymbolKey`.
- `code`: complete replacement C# member declaration.
- `sessionId`: optional durable session handle.
- `manifestJson`: optional Model-intent manifest.

### `add_using` / `remove_using`

Stages adding or removing a using directive in a C# source file.

Arguments:

- `path`: watched source file path, absolute or relative to the watched solution folder.
- `namespace`: namespace to add or remove.
- `sessionId`: optional durable session handle.
- `manifestJson`: optional Model-intent manifest.

### `set_type_partial`

Stages adding or removing the `partial` modifier on one C# type declaration. Use this before adding a companion partial file/member when the original type is not already partial. This produces a full staged candidate and does not overwrite watched source.

Arguments:

- `path`: watched source file path, absolute or relative to the watched solution folder.
- `containingType`: containing type name.
- `isPartial`: true to require `partial`; false to remove `partial`.
- `sessionId`: optional durable session handle.
- `manifestJson`: optional Model-intent manifest.

### `add_symbol` / `remove_symbol`

Stages adding or removing one C# member. `add_symbol` takes a containing type and complete member declaration. `remove_symbol` takes structured selector JSON.

Arguments:

- `path`: watched source file path, absolute or relative to the watched solution folder.
- `containingType`: containing type name for `add_symbol`.
- `symbolType`: expected symbol kind for `add_symbol`.
- `code`: complete C# member declaration for `add_symbol`.
- `afterSymbol`: optional placement hint for `add_symbol`.
- `symbolSelectorJson`: structured selector JSON for `remove_symbol`.
- `sessionId`: optional durable session handle.
- `manifestJson`: optional Model-intent manifest.

### Typed member insertion tools

Prefer these narrow tools over generic `add_symbol` when the member kind is known:

- `add_field`
- `add_property`
- `add_method`
- `add_constructor`
- `add_nested_type`

They all stage a complete candidate file, preserve local insertion trivia, run localized formatting on the inserted member, and do not overwrite watched source.

Common arguments:

- `path`: watched source file path, absolute or relative to the watched solution folder.
- `containingType`: containing type name.
- `declaration`: complete C# member/type declaration.
- `afterSymbol`: optional existing member name after which to insert the new member.
- `sessionId`: optional durable session handle.
- `manifestJson`: optional Model-intent manifest.

Use `add_nested_type` for nested classes, structs, interfaces, records, and enums. Use generic `add_symbol` only when the narrow tools do not fit.

### `record_diff_decision`

Classifies the completed WinMerge review for a staged edit and enforces the strict v1 all-or-none vote-plus-hash gate.

Arguments:

- `stagedRecordId`: staged edit record id returned by a staging tool such as `submit_file`, `submit_symbol`, `set_type_partial`, `add_symbol`, `remove_symbol`, `add_using`, or `remove_using`.
- `decision`: Operator-reported outcome, `accepted` or `rejected`.
- `note`: optional Operator note.
- `sessionId`: optional durable session handle. Defaults to the staged record session when present.

The `decision` argument is not the authority. It is the Operator's report of what they believe happened:

- `accepted`: WinMerge saved the full staged candidate into the watched file.
- `rejected`: WinMerge was not saved and the watched file should remain at the original baseline.

Decision behavior is vote-plus-hash agreement:

- reported `accepted` and watched hash equals staged proposal hash -> `accepted`
- reported `accepted` and watched normalized hash equals staged normalized hash -> `accepted-normalized`
- reported `accepted` and watched hash equals original baseline hash -> `dirty-unexpected`
- reported `accepted` and watched hash matches neither original nor staged -> `dirty-unexpected`
- reported `rejected` and watched hash equals original baseline hash -> `rejected`
- reported `rejected` and watched hash equals staged proposal hash -> `dirty-unexpected`
- reported `rejected` and watched hash matches neither original nor staged -> `dirty-unexpected`

The Operator report is not authority by itself. The hash is not enough by itself. Final classification is the agreement between the reported decision and the watched file hash. `accepted-normalized` is reserved for byte-shape-only drift such as BOM or line-ending changes from the diff tool; the decision response includes normalized hashes when that path is evaluated.

The response includes hashes, queue status, decision record path, and whether the reported outcome matched the computed classification. It returns no file content.

### `launch_staged_diff`

Launches WinMerge for an existing staged edit record and returns review paths plus launch details. This tool exists for MCP clients such as Claude Desktop that can call Monitor MCP tools but do not have a separate Host or sidecar process available to open the GUI diff.

Arguments:

- `stagedRecordId`: staged edit record id returned by `submit_file`, `submit_symbol`, `add_symbol`, `remove_symbol`, `add_using`, or `remove_using`.
- `forceReviewOnOverlayErrors`: optional boolean. Leave `false` unless the Operator explicitly asked to review a compile-failed staged candidate.

Behavior:

- reads the staged record
- verifies watched source and staged candidate files still exist
- if overlay compile validation has errors, asks the WinForms Host over the hub for an explicit `force_review` decision before launching WinMerge
- if the Host is unavailable, or the Operator cancels, returns a not-launched result so the agent can fix diagnostics first
- launches WinMerge against watched source and staged candidate
- returns `sourceFilePath`, `stagedFilePath`, `diffToolPath`, `processId`, launch arguments, validation gate status when applicable, and a next-step reminder

It does not classify, accept, reject, hash, or mutate source. After Operator review, call `record_diff_decision`.

Queue rule: any not-launched result from this tool stops the current review chain. For multi-file work, do not open the next file after `overlay-errors-review-cancelled`, `overlay-errors-host-unavailable`, `source-missing`, `staged-file-missing`, `winmerge-not-found`, or another blocked launch state. Return the diagnostics/status to the agent, stage a corrected candidate, then retry the queue from the blocked item.

Server-side queue block: when an overlay-error review is cancelled by the Operator or the Host is unavailable, the staged record queue status becomes `blocked-overlay-validation`. Later `launch_staged_diff` calls for other staged records in the same monitor session return `review-chain-blocked` until the blocked item is fixed or explicitly force-reviewed. Host-unavailable is recorded as `host_unavailable`, not as an Operator cancel.

Multi-file overlay expectation: for coupled C# changes, use one monitor session and pass the same `sessionId` to every staging call before the first review launch. Overlay validation reads the staged files in that session together, while WinMerge review remains serial.

### Run History Tools

- `list_monitor_runs(maxEntries?)`: reads monitor-owned run history entries from `Working\History\_runs.json`.
- `get_monitor_run(runId)`: returns entries for one recorded run id.

### Ledger Tools

- `list_ledgers(maxEntries?)`: lists monitor-owned per-file ledgers under `Working\History\Ledgers`.
- `get_ledger(sourceFilePath?, ledgerPath?)`: reads one ledger by watched source path or explicit ledger path under the ledger root.

### `prune_monitor_history`

Archives old monitor-owned history snapshots and prunes old ledgers. This does not touch watched source files.

### Command-Line Breadcrumb

The old monitor executable accepted flags such as `--refresh-only`, `--compare-only`, `--no-prune`, and `--ledger-summary`.

Those flags are not exposed as the primary MCP API. MCP clients should call typed tools directly:

- `--refresh-only` -> `refresh_file`
- `--compare-only` -> `compare_file`
- `--ledger-summary` -> `compare_file.ledgerSummary`
- `--no-prune` -> do not call `prune_monitor_history`

A future command-line bridge can translate legacy flags into these typed tool calls if needed.

### `get_tool_manifest`

Returns this manifest so MCP clients can understand the current and planned tool surface.

### `get_staging_guide`

Returns the normal Claude review guidance from `Docs/Skills/SystemMonitorStaging.md` and `Docs/Skills/SessionOverlayValidation.md`.

Use this after `get_tool_manifest` when the client needs the practical edit loop, session-overlay staging rules, and multi-file review guidance. This is review-facing guidance. It does not include debug smoke coverage.

### `get_smoke_test_catalog`

Debug/maintainer tool. Returns `Docs/SmokeTestCatalog.md` so maintainers can discover runnable smoke modes, coverage areas, output artifacts, and remaining smoke gaps. This is not part of the normal Claude review or edit-planning path.
## Planned Work

Future MCP tools, hardening notes, diff workflow plans, and smoke-test command references live in Docs/McpServerPlannedWork.md.

The live manifest intentionally keeps planned/design material out of the current tool contract so MCP clients do not confuse roadmap notes with callable tools.

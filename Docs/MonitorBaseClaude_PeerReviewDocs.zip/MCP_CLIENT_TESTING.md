# MCP Client Testing

This workspace has a project-scoped Claude Code MCP configuration in `.mcp.json`.

Claude-facing project rules live in `CLAUDE.md`. Claude Desktop tests should paste or attach those rules if Desktop does not read the file automatically.

## Server

```text
C:\VSCodeProjects\MonitorBaseClaude\MonitorBaseClaude.McpServer\bin\Debug\net10.0\MonitorBaseClaude.McpServer.exe
```

Build it before opening Claude Code:

```powershell
dotnet build C:\VSCodeProjects\MonitorBaseClaude\MonitorBaseClaude.McpServer\MonitorBaseClaude.McpServer.csproj
```

## Claude Code / VS Code Test

1. Open `C:\VSCodeProjects\MonitorBaseClaude` in VS Code.
2. Install/open Claude Code.
3. In the Claude Code panel, run `/mcp`.
4. Approve the project-scoped server if prompted.
5. Confirm `monitor-base-claude` is connected.
6. Ask Claude:

```text
Use the monitor-base-claude MCP server. Call get_monitor_status, then call get_tool_manifest, and summarize what monitor project is being ported.
```

7. Ask a source-map smoke prompt:

```text
Use the monitor-base-claude MCP server. Call get_source_map for Data\BaseTableRepository.cs with scope file. Do not read the full file yet. Tell me which symbol you would read next before proposing an edit.
```

8. For related-file context, ask:

```text
Use find_file and get_source_map to inspect the related files for an edit under the watched project. Prefer get_symbol for bodies and use get_file only if the source map is not enough.
```

## Expected Tools

- `get_monitor_status`
- `get_tool_manifest`
- `find_file`
- `get_source_map`
- `get_symbol`
- `list_watched_projects` temporary discovery helper

The real migration rule is that the legacy monitor command/help surface becomes typed MCP tools. The manifest is the bridge document while the tools are ported one by one.

## Roslyn CodeLens Pairing

Use Roslyn CodeLens MCP for semantic questions such as diagnostics, references, callers, implementations, type hierarchy, dependency analysis, and generated code. Use Monitor MCP for staging, hashes, WinMerge review paths, ledgers, and `record_diff_decision`.

The expected C# context loop is:

```text
find_file -> get_source_map -> get_symbol -> get_file only when needed
```

Do not add source process markers or glyph/emoji anchors. Routine workflow state belongs in Monitor-owned staged records, sessions, ledgers, or review docs.

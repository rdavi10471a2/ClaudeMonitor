# MonitorBaseClaude Agent Rules

This project is a monitor and MCP workflow host. Treat watched source as protected source, not as a scratchpad.

## Required Edit Loop

For watched project source edits, use the Monitor MCP workflow:

1. Find related files with `find_file`.
2. Read structure with `get_source_map` for C# files, folders, or project slices.
3. Read the smallest needed body with `get_symbol`.
4. Use `get_file` only when symbol/source-map context is not enough.
5. Stage a complete candidate with `submit_file` or a symbol staging tool.
6. Let the Host or sidecar open WinMerge between the real watched file and the staged candidate.
7. The Operator either saves the whole candidate in WinMerge or leaves source unchanged.
8. Call `record_diff_decision`.
9. Trust the hash classification, not the reported outcome text.

The Monitor Tool Server never directly overwrites watched source. WinMerge save/no-save is the physical mutation path in the current workflow.

## All-Or-None Gate

The diff is a sanity viewer, not a manual merge workspace.

- Do not hand-edit either side of the diff.
- Do not partially merge hunks.
- Do not repair the candidate in WinMerge.
- If the candidate is close but wrong, reject it and generate a new staged candidate.

Classification is hash-gated:

- `accepted`: watched hash equals staged candidate hash.
- `rejected`: watched hash equals original baseline hash.
- `dirty-unexpected`: watched hash equals neither and the file is blocked until refreshed or inspected.

## Source Structure

The current watched file is a voting member in the loop. It carries the prior converged pattern: names, order, comments, attributes, boundaries, namespaces, partial-class shape, and local style.

Pattern conformance does not freeze structure. Structural changes are allowed when they are explicit, bounded, staged, reviewed, and accepted all-or-none. We are preventing accidental structural drift, not deliberate architectural evolution.

## Monitor MCP vs CodeLens MCP

Use the Monitor MCP server for workflow state, sessions, staged candidates, hashes, ledgers, diff review coordination, and accept/reject classification.

Use Roslyn CodeLens MCP for external code intelligence: diagnostics, references, callers, type hierarchy, dependency analysis, generated code, and broad semantic questions.

`get_source_map` is a Monitor-owned read/discovery tool. It is expected before C# edits because it gives compact current structure and stable lexical symbol keys without loading full bodies.

## Marker And Glyph Rules

Do not add process markers to source:

- No `AI edit here`.
- No `TODO monitor anchor`.
- No `... existing code ...`.
- No temporary workflow comments.

Routine workflow notes belong in monitor-owned staged records, sessions, ledgers, or docs.

Do not use emoji, glyphs, or decorative Unicode as anchors, markers, or edit instructions. They are fragile in diffs, tokenization, copy/paste, encodings, and context patches. If existing source contains glyphs, treat them as legacy human content and never as an edit anchor.

Source comments are allowed only when they explain real code behavior. Domain metadata such as `AIFileContext` and `FileVersion` may be preserved or updated when it is part of the watched project's convention.

## Razor Files

Razor files are not plain C# files. Do not apply C# Roslyn symbol surgery directly to `.razor` or `.cshtml` source. Use read/find/full-file staging and diff review until Razor-aware validation is available.


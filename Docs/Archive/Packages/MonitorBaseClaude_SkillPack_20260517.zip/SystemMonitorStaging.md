# System Monitor Staging

Use when changing watched C# source.

## Rules

- Do not edit watched source directly.
- All watched-source changes go through System Monitor staging.
- Use the smallest safe edit unit: symbol edit before whole-file replacement.
- Stage candidates, let System Monitor validate syntax/overlay compilation, then use Operator review.
- For coupled multi-file C# edits, stage every file in one monitor session before the first review launch so overlay validation sees the whole proposed WriteSet.
- Record the Operator decision with `record_diff_decision`.
- Stop on `dirty-unexpected`; recovery is explicit refresh/rebase/restage or Operator reconcile.

## Usual Flow

```text
get_monitor_status
get_workflow_status
find_file, if path is uncertain
get_source_map(scope: "file", mode: "selector")
get_symbol for the smallest needed body
submit_symbol / add_symbol / remove_symbol / add_using / remove_using / set_type_partial
Operator review
record_diff_decision
```

For multi-file work:

```text
start_monitor_session
stage file A with sessionId
stage file B with sessionId
overlay compile validates A+B together
launch/review file A
record decision for file A
launch/review file B
record decision for file B
```

For risky edits, name:

- **ReadSet**: files/symbols observed.
- **WriteSet**: files/symbols intended for mutation.

Long reference: `Docs/AgentToolCallPlaybook.md`.

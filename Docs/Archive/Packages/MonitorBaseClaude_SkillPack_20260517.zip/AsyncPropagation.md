# Async Propagation

Use when making a C# method async, changing a signature, or updating callers.

## Rules

- Do not stage before references/callers/implementations are understood.
- Caller conversion may recurse upward through the call chain.
- Stop async propagation at explicit boundaries: UI event handlers, commands, background entry points, public API sync wrappers, or Operator-designated boundaries.
- Run diagnostics after staged edits compile.
- Keep the WriteSet explicit for multi-file edits.

## Usual Flow

```text
search_symbols(query)
get_type_overview(typeName)
find_references(symbol)
find_callers(symbol)
find_implementations(symbol)
analyze_change_impact(symbol)
System Monitor source maps/symbols for each edit target
stage bounded candidates through System Monitor
get_diagnostics after staged compile
```

Long reference: `Docs/ClaudeRoslynSystemMonitorSkill.md`.

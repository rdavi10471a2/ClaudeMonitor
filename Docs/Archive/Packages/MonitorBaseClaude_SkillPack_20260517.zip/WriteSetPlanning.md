# WriteSet Planning

Use before staging when a task can affect more than one file, symbol, interface, caller, or generated companion.

## Rules

- Identify the **ReadSet**: files and symbols inspected before editing.
- Identify the **WriteSet**: files and symbols intended for mutation.
- The WriteSet is how the agent declares that this is a one-file, two-file, or three-plus-file merge before any review window opens.
- Do not stage until the affected edit set is understood.
- If a change is coupled across files, use one monitor session for the whole WriteSet.
- Do not hide a multi-file change as a sequence of unrelated single-file edits.

## Coupling Triggers

- Signature, interface, base class, override, or async changes.
- Moving SQL/query text into a companion partial or helper type.
- Adding/removing constructor parameters, fields, or injected services.
- Adding a method and updating callers.
- Splitting a class, extracting a partial, or moving a member group.

## Expected Output

Before staging, report:

```text
ReadSet:
- file/symbol observed

WriteSet:
- file/symbol to stage

Coupling:
- why these edits must validate together, or "none"

Merge shape:
- one-file | two-file | three-plus-file
```

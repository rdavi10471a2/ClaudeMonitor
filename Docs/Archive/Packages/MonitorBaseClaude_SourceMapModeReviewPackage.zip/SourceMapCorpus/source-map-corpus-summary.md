# Source Map Corpus Smoke Summary

Generated: 2026-05-16T01:09:55.8015221-05:00
Started: `2026-05-16T01:09:53.8836774-05:00`
Finished: `2026-05-16T01:09:55.7894509-05:00`
Watched root: `C:\Schema Studio - DBV2`
Target: `C:\Schema Studio - DBV2`

## Totals

Files scanned: `32`
Successful maps: `32`
Error maps: `0`
Source bytes: `154,562`
Source-map bytes: `506,400`
Compact index bytes: `295,794`
Navigation index bytes: `102,570`
Map/source byte ratio: `3.276`
Compact/source byte ratio: `1.914`
Navigation/source byte ratio: `0.664`
Estimated source tokens: `38,613`
Estimated source-map tokens: `126,600`
Estimated compact-index tokens: `73,949`
Estimated navigation-index tokens: `25,643`
Map/source token ratio: `3.279`
Compact/source token ratio: `1.915`
Navigation/source token ratio: `0.664`
Compact index: `C:\VSCodeProjects\MonitorBaseClaude\Working\History\ToolSmokeTests\20260516_010953\source-map-corpus\source-map-compact-index.json`
Navigation index: `C:\VSCodeProjects\MonitorBaseClaude\Working\History\ToolSmokeTests\20260516_010953\source-map-corpus\source-map-navigation-index.json`

Token estimates use a simple character/4 proxy. They are not provider billing numbers, but they are good enough to compare full source context, full-fidelity source-map artifacts, compact selector indexes, and navigation-only indexes.

## Symbol Totals

Symbols: `416`
Types: `45`
Methods: `117`
Fields: `118`
Properties: `99`
Events: `5`
Diagnostics: `0`

## Largest Source Files

| File | Source Bytes | Map Bytes | Ratio | Symbols | Methods | Diagnostics | Parse |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `EditorSurface\ExplorerControl.cs` | 21,366 | 46,478 | 2.175 | 43 | 16 | 0 | `ok` |
| `Data\BaseTableColumnRepository.cs` | 13,507 | 10,431 | 0.772 | 8 | 6 | 0 | `ok` |
| `UI\BaseTableEditorForm.cs` | 11,094 | 24,101 | 2.172 | 22 | 7 | 0 | `ok` |
| `Data\TargetScriptRepository.cs` | 10,422 | 18,808 | 1.805 | 15 | 11 | 0 | `ok` |
| `UI\DatabaseManagerForm.cs` | 10,239 | 20,753 | 2.027 | 19 | 8 | 0 | `ok` |
| `Models\BaseTableColumnDefinition.cs` | 7,758 | 47,702 | 6.149 | 37 | 4 | 0 | `ok` |
| `Configuration\AppConfig.cs` | 7,632 | 33,060 | 4.332 | 19 | 5 | 0 | `ok` |
| `Models\BaseTableDefinition.cs` | 6,296 | 38,428 | 6.104 | 30 | 3 | 0 | `ok` |
| `EditorSurface\SchemaViewer.cs` | 5,869 | 15,422 | 2.628 | 14 | 6 | 0 | `ok` |
| `Models\DatabaseDefinition.cs` | 5,782 | 30,453 | 5.267 | 23 | 4 | 0 | `ok` |
| `EditorSurface\LogControl.cs` | 5,596 | 16,049 | 2.868 | 14 | 7 | 0 | `ok` |
| `AI\AIAttributes.cs` | 5,450 | 42,434 | 7.786 | 38 | 0 | 0 | `ok` |
| `EditorSurface\EditorSurfaceControl.cs` | 4,694 | 10,349 | 2.205 | 9 | 2 | 0 | `ok` |
| `UI\TableRelationshipViewer.cs` | 4,464 | 8,537 | 1.912 | 7 | 1 | 0 | `ok` |
| `Data\BaseTableRepository.cs` | 4,300 | 9,817 | 2.283 | 8 | 6 | 0 | `ok` |
| `UI\LimitedTextEditorForm.cs` | 3,649 | 11,884 | 3.257 | 11 | 0 | 0 | `ok` |
| `Services\SchemaDiscovery.cs` | 3,499 | 3,113 | 0.890 | 2 | 1 | 0 | `ok` |
| `Services\LogService.cs` | 3,205 | 16,128 | 5.032 | 13 | 5 | 0 | `ok` |
| `Data\DataBaseRepository.cs` | 3,115 | 8,292 | 2.662 | 7 | 5 | 0 | `ok` |
| `UI\PropertyGridSupport.cs` | 2,902 | 21,389 | 7.370 | 18 | 6 | 0 | `ok` |

## Largest Source Maps

| File | Source Bytes | Map Bytes | Ratio | Symbols | Methods | Diagnostics | Parse |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `Models\BaseTableColumnDefinition.cs` | 7,758 | 47,702 | 6.149 | 37 | 4 | 0 | `ok` |
| `EditorSurface\ExplorerControl.cs` | 21,366 | 46,478 | 2.175 | 43 | 16 | 0 | `ok` |
| `AI\AIAttributes.cs` | 5,450 | 42,434 | 7.786 | 38 | 0 | 0 | `ok` |
| `Models\BaseTableDefinition.cs` | 6,296 | 38,428 | 6.104 | 30 | 3 | 0 | `ok` |
| `Configuration\AppConfig.cs` | 7,632 | 33,060 | 4.332 | 19 | 5 | 0 | `ok` |
| `Models\DatabaseDefinition.cs` | 5,782 | 30,453 | 5.267 | 23 | 4 | 0 | `ok` |
| `UI\BaseTableEditorForm.cs` | 11,094 | 24,101 | 2.172 | 22 | 7 | 0 | `ok` |
| `UI\PropertyGridSupport.cs` | 2,902 | 21,389 | 7.370 | 18 | 6 | 0 | `ok` |
| `UI\DatabaseManagerForm.cs` | 10,239 | 20,753 | 2.027 | 19 | 8 | 0 | `ok` |
| `Data\TargetScriptRepository.cs` | 10,422 | 18,808 | 1.805 | 15 | 11 | 0 | `ok` |
| `Services\LogService.cs` | 3,205 | 16,128 | 5.032 | 13 | 5 | 0 | `ok` |
| `EditorSurface\LogControl.cs` | 5,596 | 16,049 | 2.868 | 14 | 7 | 0 | `ok` |
| `EditorSurface\SchemaViewer.cs` | 5,869 | 15,422 | 2.628 | 14 | 6 | 0 | `ok` |
| `Data\RelationshipRepository.cs` | 1,571 | 13,347 | 8.496 | 12 | 1 | 0 | `ok` |
| `UI\LimitedTextEditorForm.cs` | 3,649 | 11,884 | 3.257 | 11 | 0 | 0 | `ok` |
| `Data\BaseTableColumnRepository.cs` | 13,507 | 10,431 | 0.772 | 8 | 6 | 0 | `ok` |
| `EditorSurface\EditorSurfaceControl.cs` | 4,694 | 10,349 | 2.205 | 9 | 2 | 0 | `ok` |
| `Data\BaseTableRepository.cs` | 4,300 | 9,817 | 2.283 | 8 | 6 | 0 | `ok` |
| `UI\AppSettingsEditor.cs` | 2,309 | 8,958 | 3.880 | 8 | 3 | 0 | `ok` |
| `UI\TableRelationshipViewer.cs` | 4,464 | 8,537 | 1.912 | 7 | 1 | 0 | `ok` |

## Highest Map/Source Ratios

| File | Source Bytes | Map Bytes | Ratio | Symbols | Methods | Diagnostics | Parse |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `SchemaStudio.cs` | 179 | 2,598 | 14.514 | 2 | 0 | 0 | `ok` |
| `Models\MetaDataType.cs` | 404 | 5,750 | 14.233 | 5 | 0 | 0 | `ok` |
| `EditorSurface\TextLengthAttribute.cs` | 310 | 4,089 | 13.190 | 3 | 0 | 0 | `ok` |
| `Data\DBIgnore.cs` | 408 | 5,117 | 12.542 | 4 | 0 | 0 | `ok` |
| `EditorSurface\CommandDispatcher.cs` | 476 | 5,083 | 10.679 | 4 | 2 | 0 | `ok` |
| `Data\RelationshipRepository.cs` | 1,571 | 13,347 | 8.496 | 12 | 1 | 0 | `ok` |
| `AI\AIAttributes.cs` | 5,450 | 42,434 | 7.786 | 38 | 0 | 0 | `ok` |
| `UI\PropertyGridSupport.cs` | 2,902 | 21,389 | 7.370 | 18 | 6 | 0 | `ok` |
| `Models\BaseTableColumnDefinition.cs` | 7,758 | 47,702 | 6.149 | 37 | 4 | 0 | `ok` |
| `Models\BaseTableDefinition.cs` | 6,296 | 38,428 | 6.104 | 30 | 3 | 0 | `ok` |
| `Models\DatabaseDefinition.cs` | 5,782 | 30,453 | 5.267 | 23 | 4 | 0 | `ok` |
| `EditorSurface\CommsnfBarControl.cs` | 1,480 | 7,657 | 5.174 | 6 | 1 | 0 | `ok` |
| `Services\LogService.cs` | 3,205 | 16,128 | 5.032 | 13 | 5 | 0 | `ok` |
| `Configuration\AppConfig.cs` | 7,632 | 33,060 | 4.332 | 19 | 5 | 0 | `ok` |
| `UI\AppSettingsEditor.cs` | 2,309 | 8,958 | 3.880 | 8 | 3 | 0 | `ok` |
| `Program.cs` | 801 | 2,842 | 3.548 | 2 | 1 | 0 | `ok` |
| `UI\LimitedMultilineEdiitor.cs` | 1,458 | 4,946 | 3.392 | 3 | 2 | 0 | `ok` |
| `UI\LimitedTextEditorForm.cs` | 3,649 | 11,884 | 3.257 | 11 | 0 | 0 | `ok` |
| `SchemaStudio.Designer.cs` | 1,872 | 5,724 | 3.058 | 5 | 2 | 0 | `ok` |
| `EditorSurface\LogControl.cs` | 5,596 | 16,049 | 2.868 | 14 | 7 | 0 | `ok` |

## Diagnostics And Errors

No parse diagnostics or source-map errors were reported.

## All Files

| File | Source Bytes | Map Bytes | Ratio | Symbols | Methods | Diagnostics | Parse |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `AI\AIAttributes.cs` | 5,450 | 42,434 | 7.786 | 38 | 0 | 0 | `ok` |
| `Configuration\AppConfig.cs` | 7,632 | 33,060 | 4.332 | 19 | 5 | 0 | `ok` |
| `Data\BaseTableColumnRepository.cs` | 13,507 | 10,431 | 0.772 | 8 | 6 | 0 | `ok` |
| `Data\BaseTableRepository.cs` | 4,300 | 9,817 | 2.283 | 8 | 6 | 0 | `ok` |
| `Data\DataBaseRepository.cs` | 3,115 | 8,292 | 2.662 | 7 | 5 | 0 | `ok` |
| `Data\DBIgnore.cs` | 408 | 5,117 | 12.542 | 4 | 0 | 0 | `ok` |
| `Data\RelationshipRepository.cs` | 1,571 | 13,347 | 8.496 | 12 | 1 | 0 | `ok` |
| `Data\TargetScriptRepository.cs` | 10,422 | 18,808 | 1.805 | 15 | 11 | 0 | `ok` |
| `EditorSurface\CommandDispatcher.cs` | 476 | 5,083 | 10.679 | 4 | 2 | 0 | `ok` |
| `EditorSurface\CommsnfBarControl.cs` | 1,480 | 7,657 | 5.174 | 6 | 1 | 0 | `ok` |
| `EditorSurface\EditorSurfaceControl.cs` | 4,694 | 10,349 | 2.205 | 9 | 2 | 0 | `ok` |
| `EditorSurface\ExplorerControl.cs` | 21,366 | 46,478 | 2.175 | 43 | 16 | 0 | `ok` |
| `EditorSurface\LogControl.cs` | 5,596 | 16,049 | 2.868 | 14 | 7 | 0 | `ok` |
| `EditorSurface\SchemaViewer.cs` | 5,869 | 15,422 | 2.628 | 14 | 6 | 0 | `ok` |
| `EditorSurface\TextLengthAttribute.cs` | 310 | 4,089 | 13.190 | 3 | 0 | 0 | `ok` |
| `Models\BaseTableColumnDefinition.cs` | 7,758 | 47,702 | 6.149 | 37 | 4 | 0 | `ok` |
| `Models\BaseTableDefinition.cs` | 6,296 | 38,428 | 6.104 | 30 | 3 | 0 | `ok` |
| `Models\DatabaseDefinition.cs` | 5,782 | 30,453 | 5.267 | 23 | 4 | 0 | `ok` |
| `Models\MetaDataType.cs` | 404 | 5,750 | 14.233 | 5 | 0 | 0 | `ok` |
| `Program.cs` | 801 | 2,842 | 3.548 | 2 | 1 | 0 | `ok` |
| `SchemaStudio.cs` | 179 | 2,598 | 14.514 | 2 | 0 | 0 | `ok` |
| `SchemaStudio.Designer.cs` | 1,872 | 5,724 | 3.058 | 5 | 2 | 0 | `ok` |
| `Services\LogService.cs` | 3,205 | 16,128 | 5.032 | 13 | 5 | 0 | `ok` |
| `Services\SchemaDiscovery.cs` | 3,499 | 3,113 | 0.890 | 2 | 1 | 0 | `ok` |
| `UI\AppSettingsEditor.cs` | 2,309 | 8,958 | 3.880 | 8 | 3 | 0 | `ok` |
| `UI\BaseTableEditorForm.cs` | 11,094 | 24,101 | 2.172 | 22 | 7 | 0 | `ok` |
| `UI\DatabaseManagerForm.cs` | 10,239 | 20,753 | 2.027 | 19 | 8 | 0 | `ok` |
| `UI\LimitedMultilineEdiitor.cs` | 1,458 | 4,946 | 3.392 | 3 | 2 | 0 | `ok` |
| `UI\LimitedTextEditorForm.cs` | 3,649 | 11,884 | 3.257 | 11 | 0 | 0 | `ok` |
| `UI\PropertyGridSupport.cs` | 2,902 | 21,389 | 7.370 | 18 | 6 | 0 | `ok` |
| `UI\ScriptViewerForm.cs` | 2,455 | 6,661 | 2.713 | 5 | 2 | 0 | `ok` |
| `UI\TableRelationshipViewer.cs` | 4,464 | 8,537 | 1.912 | 7 | 1 | 0 | `ok` |

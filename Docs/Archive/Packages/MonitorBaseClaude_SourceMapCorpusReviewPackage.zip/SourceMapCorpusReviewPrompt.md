# Source Map Corpus Review Prompt

Use this prompt with ChatGPT/Claude to review the DBV2-wide source-map corpus smoke artifacts.

```text
You are reviewing MonitorBaseClaude source-map artifacts for an MCP-assisted C# edit workflow.

Context:

- MonitorBaseClaude is an MCP/WinForms monitor workflow.
- The intended agent loop is:
  find_file -> get_source_map -> get_symbol -> stage complete candidate -> WinMerge review/save -> record_diff_decision.
- get_source_map is read-only discovery. It is not the edit verifier and not the accept/reject gate.
- Final decisions use vote-plus-hash agreement:
  reported accepted + watched hash == staged hash -> accepted
  reported rejected + watched hash == original hash -> rejected
  any mismatch -> dirty-unexpected
- WinMerge is the Host-owned review/save surface, not a manual repair or partial hunk merge surface.

New DBV2 source-map corpus smoke:

Command:

dotnet run --project .\MonitorBaseClaude.ToolSmokeTests\MonitorBaseClaude.ToolSmokeTests.csproj -- --source-map-corpus-smoke

Latest run:

- C# files: 32
- Successful maps: 32
- Error maps: 0
- Diagnostics: 0
- Source bytes: 154,562
- Raw source-map bytes: 508,629
- Compact selector index bytes: 155,723
- Navigation index bytes: 71,058
- Estimated source tokens: 38,613
- Estimated raw source-map tokens: 127,158
- Estimated compact-index tokens: 38,931
- Estimated navigation-index tokens: 17,765

Artifacts in this package:

- SourceMapCorpus/source-map-corpus-summary.md
- SourceMapCorpus/source-map-corpus-analysis.json
- SourceMapCorpus/source-map-compact-index.json
- SourceMapCorpus/source-map-navigation-index.json
- MCP_CLIENT_TESTING.md
- Docs/ExistingCodeEditCoveragePlan.md
- MonitorBaseClaude.McpServer/MONITOR_MCP_TOOL_MANIFEST.md

Please review the artifacts and recommend the most useful source-map response shapes for Claude-like MCP clients.

Questions:

1. Should get_source_map expose explicit modes such as navigation, selector, and full?
2. Which mode should be default for file scope, folder scope, and project scope?
3. What exact fields belong in each mode?
4. Should navigation mode include attributes, diagnostics, baseTypes, events, partial grouping, usings, or only file/type/member shape?
5. Should selector mode include private members by default, or require includePrivate=true?
6. What size/token budget should the tool enforce before asking the model to narrow path or scope?
7. What related-file hints should be added before full Roslyn CodeLens semantic integration?
8. Does the compact selector index have enough data to support stable get_symbol and future submit_symbol selectors?
9. Is the navigation index enough for broad orientation without dumping full file bodies?
10. What should be added, removed, or renamed before this becomes the default Claude-facing source-map lane?

Please separate recommendations into:

- implement now
- useful next
- defer until Roslyn CodeLens / compilation context
- avoid
```


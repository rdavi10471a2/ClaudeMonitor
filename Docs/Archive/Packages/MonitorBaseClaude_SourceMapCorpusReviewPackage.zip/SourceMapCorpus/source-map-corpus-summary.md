# Source Map Corpus Smoke Summary

Generated: 2026-05-16T00:37:17.8552464-05:00
Started: `2026-05-16T00:37:16.4195678-05:00`
Finished: `2026-05-16T00:37:17.8414630-05:00`
Watched root: `C:\Schema Studio - DBV2`
Target: `C:\Schema Studio - DBV2`

## Totals

Files scanned: `32`
Successful maps: `32`
Error maps: `0`
Source bytes: `154,562`
Source-map bytes: `508,629`
Compact index bytes: `155,723`
Navigation index bytes: `71,058`
Map/source byte ratio: `3.291`
Compact/source byte ratio: `1.008`
Navigation/source byte ratio: `0.460`
Estimated source tokens: `38,613`
Estimated source-map tokens: `127,158`
Estimated compact-index tokens: `38,931`
Estimated navigation-index tokens: `17,765`
Map/source token ratio: `3.293`
Compact/source token ratio: `1.008`
Navigation/source token ratio: `0.460`
Compact index: `C:\VSCodeProjects\MonitorBaseClaude\Working\History\ToolSmokeTests\20260516_003716\source-map-corpus\source-map-compact-index.json`
Navigation index: `C:\VSCodeProjects\MonitorBaseClaude\Working\History\ToolSmokeTests\20260516_003716\source-map-corpus\source-map-navigation-index.json`

Token estimates use a simple character/4 proxy. They are not provider billing numbers, but they are good enough to compare full source context, full-fidelity source-map artifacts, compact selector indexes, and navigation-only indexes.

## Symbol Totals

Symbols: `416`
Types: `45`
Methods: `117`
Fields: `118`
Properties: `99`
Events: `5`
Diagnostics: `0`

## Largest Source Files

| File | Source Bytes | Map Bytes | Ratio | Symbols | Methods | Diagnostics | Parse |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `EditorSurface\ExplorerControl.cs` | 21,366 | 46,343 | 2.169 | 43 | 16 | 0 | `ok` |
| `Data\BaseTableColumnRepository.cs` | 13,507 | 10,288 | 0.762 | 8 | 6 | 0 | `ok` |
| `UI\BaseTableEditorForm.cs` | 11,094 | 23,966 | 2.160 | 22 | 7 | 0 | `ok` |
| `Data\TargetScriptRepository.cs` | 10,422 | 18,673 | 1.792 | 15 | 11 | 0 | `ok` |
| `UI\DatabaseManagerForm.cs` | 10,239 | 20,618 | 2.014 | 19 | 8 | 0 | `ok` |
| `Models\BaseTableColumnDefinition.cs` | 7,758 | 49,705 | 6.407 | 37 | 4 | 0 | `ok` |
| `Configuration\AppConfig.cs` | 7,632 | 33,754 | 4.423 | 19 | 5 | 0 | `ok` |
| `Models\BaseTableDefinition.cs` | 6,296 | 40,116 | 6.372 | 30 | 3 | 0 | `ok` |
| `EditorSurface\SchemaViewer.cs` | 5,869 | 15,287 | 2.605 | 14 | 6 | 0 | `ok` |
| `Models\DatabaseDefinition.cs` | 5,782 | 32,071 | 5.547 | 23 | 4 | 0 | `ok` |
| `EditorSurface\LogControl.cs` | 5,596 | 15,914 | 2.844 | 14 | 7 | 0 | `ok` |
| `AI\AIAttributes.cs` | 5,450 | 42,283 | 7.758 | 38 | 0 | 0 | `ok` |
| `EditorSurface\EditorSurfaceControl.cs` | 4,694 | 10,214 | 2.176 | 9 | 2 | 0 | `ok` |
| `UI\TableRelationshipViewer.cs` | 4,464 | 8,402 | 1.882 | 7 | 1 | 0 | `ok` |
| `Data\BaseTableRepository.cs` | 4,300 | 9,674 | 2.250 | 8 | 6 | 0 | `ok` |
| `UI\LimitedTextEditorForm.cs` | 3,649 | 11,741 | 3.218 | 11 | 0 | 0 | `ok` |
| `Services\SchemaDiscovery.cs` | 3,499 | 2,979 | 0.851 | 2 | 1 | 0 | `ok` |
| `Services\LogService.cs` | 3,205 | 15,993 | 4.990 | 13 | 5 | 0 | `ok` |
| `Data\DataBaseRepository.cs` | 3,115 | 8,149 | 2.616 | 7 | 5 | 0 | `ok` |
| `UI\PropertyGridSupport.cs` | 2,902 | 21,214 | 7.310 | 18 | 6 | 0 | `ok` |

## Largest Source Maps

| File | Source Bytes | Map Bytes | Ratio | Symbols | Methods | Diagnostics | Parse |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `Models\BaseTableColumnDefinition.cs` | 7,758 | 49,705 | 6.407 | 37 | 4 | 0 | `ok` |
| `EditorSurface\ExplorerControl.cs` | 21,366 | 46,343 | 2.169 | 43 | 16 | 0 | `ok` |
| `AI\AIAttributes.cs` | 5,450 | 42,283 | 7.758 | 38 | 0 | 0 | `ok` |
| `Models\BaseTableDefinition.cs` | 6,296 | 40,116 | 6.372 | 30 | 3 | 0 | `ok` |
| `Configuration\AppConfig.cs` | 7,632 | 33,754 | 4.423 | 19 | 5 | 0 | `ok` |
| `Models\DatabaseDefinition.cs` | 5,782 | 32,071 | 5.547 | 23 | 4 | 0 | `ok` |
| `UI\BaseTableEditorForm.cs` | 11,094 | 23,966 | 2.160 | 22 | 7 | 0 | `ok` |
| `UI\PropertyGridSupport.cs` | 2,902 | 21,214 | 7.310 | 18 | 6 | 0 | `ok` |
| `UI\DatabaseManagerForm.cs` | 10,239 | 20,618 | 2.014 | 19 | 8 | 0 | `ok` |
| `Data\TargetScriptRepository.cs` | 10,422 | 18,673 | 1.792 | 15 | 11 | 0 | `ok` |
| `Services\LogService.cs` | 3,205 | 15,993 | 4.990 | 13 | 5 | 0 | `ok` |
| `EditorSurface\LogControl.cs` | 5,596 | 15,914 | 2.844 | 14 | 7 | 0 | `ok` |
| `EditorSurface\SchemaViewer.cs` | 5,869 | 15,287 | 2.605 | 14 | 6 | 0 | `ok` |
| `Data\RelationshipRepository.cs` | 1,571 | 13,204 | 8.405 | 12 | 1 | 0 | `ok` |
| `UI\LimitedTextEditorForm.cs` | 3,649 | 11,741 | 3.218 | 11 | 0 | 0 | `ok` |
| `Data\BaseTableColumnRepository.cs` | 13,507 | 10,288 | 0.762 | 8 | 6 | 0 | `ok` |
| `EditorSurface\EditorSurfaceControl.cs` | 4,694 | 10,214 | 2.176 | 9 | 2 | 0 | `ok` |
| `Data\BaseTableRepository.cs` | 4,300 | 9,674 | 2.250 | 8 | 6 | 0 | `ok` |
| `UI\AppSettingsEditor.cs` | 2,309 | 8,823 | 3.821 | 8 | 3 | 0 | `ok` |
| `UI\TableRelationshipViewer.cs` | 4,464 | 8,402 | 1.882 | 7 | 1 | 0 | `ok` |

## Highest Map/Source Ratios

| File | Source Bytes | Map Bytes | Ratio | Symbols | Methods | Diagnostics | Parse |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `Models\MetaDataType.cs` | 404 | 5,616 | 13.901 | 5 | 0 | 0 | `ok` |
| `SchemaStudio.cs` | 179 | 2,464 | 13.765 | 2 | 0 | 0 | `ok` |
| `EditorSurface\TextLengthAttribute.cs` | 310 | 3,955 | 12.758 | 3 | 0 | 0 | `ok` |
| `Data\DBIgnore.cs` | 408 | 4,983 | 12.213 | 4 | 0 | 0 | `ok` |
| `EditorSurface\CommandDispatcher.cs` | 476 | 4,949 | 10.397 | 4 | 2 | 0 | `ok` |
| `Data\RelationshipRepository.cs` | 1,571 | 13,204 | 8.405 | 12 | 1 | 0 | `ok` |
| `AI\AIAttributes.cs` | 5,450 | 42,283 | 7.758 | 38 | 0 | 0 | `ok` |
| `UI\PropertyGridSupport.cs` | 2,902 | 21,214 | 7.310 | 18 | 6 | 0 | `ok` |
| `Models\BaseTableColumnDefinition.cs` | 7,758 | 49,705 | 6.407 | 37 | 4 | 0 | `ok` |
| `Models\BaseTableDefinition.cs` | 6,296 | 40,116 | 6.372 | 30 | 3 | 0 | `ok` |
| `Models\DatabaseDefinition.cs` | 5,782 | 32,071 | 5.547 | 23 | 4 | 0 | `ok` |
| `EditorSurface\CommsnfBarControl.cs` | 1,480 | 7,615 | 5.145 | 6 | 1 | 0 | `ok` |
| `Services\LogService.cs` | 3,205 | 15,993 | 4.990 | 13 | 5 | 0 | `ok` |
| `Configuration\AppConfig.cs` | 7,632 | 33,754 | 4.423 | 19 | 5 | 0 | `ok` |
| `UI\AppSettingsEditor.cs` | 2,309 | 8,823 | 3.821 | 8 | 3 | 0 | `ok` |
| `Program.cs` | 801 | 2,708 | 3.381 | 2 | 1 | 0 | `ok` |
| `UI\LimitedMultilineEdiitor.cs` | 1,458 | 4,812 | 3.300 | 3 | 2 | 0 | `ok` |
| `UI\LimitedTextEditorForm.cs` | 3,649 | 11,741 | 3.218 | 11 | 0 | 0 | `ok` |
| `SchemaStudio.Designer.cs` | 1,872 | 5,590 | 2.986 | 5 | 2 | 0 | `ok` |
| `EditorSurface\LogControl.cs` | 5,596 | 15,914 | 2.844 | 14 | 7 | 0 | `ok` |

## Diagnostics And Errors

No parse diagnostics or source-map errors were reported.

## All Files

| File | Source Bytes | Map Bytes | Ratio | Symbols | Methods | Diagnostics | Parse |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `AI\AIAttributes.cs` | 5,450 | 42,283 | 7.758 | 38 | 0 | 0 | `ok` |
| `Configuration\AppConfig.cs` | 7,632 | 33,754 | 4.423 | 19 | 5 | 0 | `ok` |
| `Data\BaseTableColumnRepository.cs` | 13,507 | 10,288 | 0.762 | 8 | 6 | 0 | `ok` |
| `Data\BaseTableRepository.cs` | 4,300 | 9,674 | 2.250 | 8 | 6 | 0 | `ok` |
| `Data\DataBaseRepository.cs` | 3,115 | 8,149 | 2.616 | 7 | 5 | 0 | `ok` |
| `Data\DBIgnore.cs` | 408 | 4,983 | 12.213 | 4 | 0 | 0 | `ok` |
| `Data\RelationshipRepository.cs` | 1,571 | 13,204 | 8.405 | 12 | 1 | 0 | `ok` |
| `Data\TargetScriptRepository.cs` | 10,422 | 18,673 | 1.792 | 15 | 11 | 0 | `ok` |
| `EditorSurface\CommandDispatcher.cs` | 476 | 4,949 | 10.397 | 4 | 2 | 0 | `ok` |
| `EditorSurface\CommsnfBarControl.cs` | 1,480 | 7,615 | 5.145 | 6 | 1 | 0 | `ok` |
| `EditorSurface\EditorSurfaceControl.cs` | 4,694 | 10,214 | 2.176 | 9 | 2 | 0 | `ok` |
| `EditorSurface\ExplorerControl.cs` | 21,366 | 46,343 | 2.169 | 43 | 16 | 0 | `ok` |
| `EditorSurface\LogControl.cs` | 5,596 | 15,914 | 2.844 | 14 | 7 | 0 | `ok` |
| `EditorSurface\SchemaViewer.cs` | 5,869 | 15,287 | 2.605 | 14 | 6 | 0 | `ok` |
| `EditorSurface\TextLengthAttribute.cs` | 310 | 3,955 | 12.758 | 3 | 0 | 0 | `ok` |
| `Models\BaseTableColumnDefinition.cs` | 7,758 | 49,705 | 6.407 | 37 | 4 | 0 | `ok` |
| `Models\BaseTableDefinition.cs` | 6,296 | 40,116 | 6.372 | 30 | 3 | 0 | `ok` |
| `Models\DatabaseDefinition.cs` | 5,782 | 32,071 | 5.547 | 23 | 4 | 0 | `ok` |
| `Models\MetaDataType.cs` | 404 | 5,616 | 13.901 | 5 | 0 | 0 | `ok` |
| `Program.cs` | 801 | 2,708 | 3.381 | 2 | 1 | 0 | `ok` |
| `SchemaStudio.cs` | 179 | 2,464 | 13.765 | 2 | 0 | 0 | `ok` |
| `SchemaStudio.Designer.cs` | 1,872 | 5,590 | 2.986 | 5 | 2 | 0 | `ok` |
| `Services\LogService.cs` | 3,205 | 15,993 | 4.990 | 13 | 5 | 0 | `ok` |
| `Services\SchemaDiscovery.cs` | 3,499 | 2,979 | 0.851 | 2 | 1 | 0 | `ok` |
| `UI\AppSettingsEditor.cs` | 2,309 | 8,823 | 3.821 | 8 | 3 | 0 | `ok` |
| `UI\BaseTableEditorForm.cs` | 11,094 | 23,966 | 2.160 | 22 | 7 | 0 | `ok` |
| `UI\DatabaseManagerForm.cs` | 10,239 | 20,618 | 2.014 | 19 | 8 | 0 | `ok` |
| `UI\LimitedMultilineEdiitor.cs` | 1,458 | 4,812 | 3.300 | 3 | 2 | 0 | `ok` |
| `UI\LimitedTextEditorForm.cs` | 3,649 | 11,741 | 3.218 | 11 | 0 | 0 | `ok` |
| `UI\PropertyGridSupport.cs` | 2,902 | 21,214 | 7.310 | 18 | 6 | 0 | `ok` |
| `UI\ScriptViewerForm.cs` | 2,455 | 6,526 | 2.658 | 5 | 2 | 0 | `ok` |
| `UI\TableRelationshipViewer.cs` | 4,464 | 8,402 | 1.882 | 7 | 1 | 0 | `ok` |
